/*
 * File:   main.c
 * Author: alanlow
 *
 * Created on April 10, 2021, 7:27 PM
 */

#include <xc.h>
//#include <PIC16F886.h>


// BEGIN CONFIG
//#pragma config FOSC = HS // Oscillator Selection bits (HS oscillator)
//#pragma config FOSC = 0x4   // Allow pins use for OSC input as GPIO
//#pragma config IRCF = 0x7   // Run Internal oscilator at 8MHz
//#pragma config SCS = ON     // Select system clock run from internal oscillator
#pragma config WDTE = ON // Watchdog Timer Enable bit (WDT enabled)
#pragma config PWRTE = OFF // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = ON // Brown-out Reset Enable bit (BOR enabled)
#pragma config LVP = OFF // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3 is digital I/O, HV on MCLR must be used for programming)
#pragma config CPD = OFF // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF // Flash Program Memory Code Protection bit (Code protection off)
//END CONFIG

#define MOT         PORTA               // Stepper motor control port
#define MOT_TRIS    TRISA               // Stepper motor port tri-state buffer
#define LED         PORTBbits.RB5       // System Status LED 
#define LED_TRIS    TRISBbits.TRISB5    // System Status LED tri-state buffer
#define R1          PORTBbits.RB7       // Switch matrix Row 1
#define R1_TRIS     TRISBbits.TRISB7    // Switch matrix Row 1 tri-sate buffer
#define R2          PORTBbits.RB6       // Switch matrix Row 2
#define R2_TRIS     TRISBbits.TRISB6    // Switch matrix Row 2 tri-state buffer
#define C1          PORTBbits.RB1       // Switch matrix Col 1
#define C1_TRIS     TRISBbits.TRISB1    // Switch matrix Col 1 tri-state buffer
#define C2          PORTCbits.RC2       // Switch matrix Col 1
#define C2_TRIS     TRISCbits.TRISC2    // Switch matrix Col 1 tri-state buffer
#define C3          PORTCbits.RC5       // Switch matrix Col 1
#define C3_TRIS     TRISCbits.TRISC5    // Switch matrix Col 1 tri-state buffer
#define LFT         PORTBbits.RB3       // IR Sensor Left
#define LFT_TRIS    TRISBbits.TRISB3    // IR Sensor Left tri-sate buffer
#define FRT         PORTBbits.RB2       // IR Sensor Front
#define FRT_TRIS    TRISBbits.TRISB2    // IR Sensor Front tri-state buffer
#define RHT         PORTBbits.RB4       // IR Sensor Right
#define RHT_TRIS    TRISBbits.TRISB4    // IR Sensor Right tri-state buffer 


void high_priority interrupt tcInt(void)
{
 // process other interrupt sources here, if required
 return;
}

void SYS_Init(void){
    
    
    // Setup System Clock
    //Clock already setup as above
    
    
    // Setup GPIO
    
    
    ////// For Stepper Motor
    
    
    ////// For I2C
    
    
    ////// For Interrupt
    
    
    ////// For IR Sensor
    
    
    ////// For Switch
    
    
    return;
}



void main(void) {
    SYS_Init();
    
    
    while(1){
       // __delay_ms(1000);
    }
            
    return;
}
